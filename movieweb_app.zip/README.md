MovieWeb App is a Flask-based web application that allows users to manage and review movies.
Features

    User authentication and registration
    List of movies for each user
    Adding, updating, and deleting movies
    Adding and deleting reviews for movies
    Recommending popular movies
    User-friendly interface

You'll need to add your API key with RapidAPI for both AI and omdbapi
        
        Just change in data_managers/sql_data_manager were you see
        your_api_here with your API key from RapidAPI. 